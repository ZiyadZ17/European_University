lecture_cnt = int(input("enter lecture cnt: "))
attendence_cnt = int(input("enter attendendce cnt: "))

p = (lecture_cnt - attendence_cnt) / lecture_cnt

s = "accepted"
if p > 0.75:
    s = "forbidden"

print(s)
