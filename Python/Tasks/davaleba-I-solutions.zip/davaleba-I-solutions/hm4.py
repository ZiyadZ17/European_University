a = int(input())
b = int(input())
c = int(input())

mx = a
if a > b and a > c:
    mx = a
elif b > a and b > c:
    mx = b
elif c > a and c > b: 
    mx = c

mn = a
if a < b and a < c:
    mn = a
elif b < a and b < c:
    mn = b
elif c < a and c < b:
    mn = c

md = a
if a != mx and a != mn:
    md = a
elif b != mx and b != mn:
    md = b
elif c != mx and c != mn:
    md = c

print(mn,md,mx)