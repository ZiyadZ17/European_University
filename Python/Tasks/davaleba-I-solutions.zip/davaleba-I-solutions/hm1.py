salary = float(input("enter salary: "))

p = 0
if salary > 1000: 
    p = 0.2

print("on hand:",salary * (1 - p))
print("budget:",salary * p)