p1 = float(input("subject 1: "))
p2 = float(input("subject 2: "))
p3 = float(input("subject 3: "))
p4 = float(input("subject 4: "))
p5 = float(input("subject 5: "))
p6 = float(input("subject 6: "))

avg = (p1 + p2 + p3 + p4 + p5 + p6) / 6

if avg >= 91 and avg <= 100:
    print("A")
elif avg >= 81:
    print("B")
elif avg >= 71:
    print("C")
elif avg >= 61:
    print("D")
elif avg >= 51:
    print("E")
else:
    print("F")

